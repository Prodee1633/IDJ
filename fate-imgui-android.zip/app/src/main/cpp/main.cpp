#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <jni.h>
#include <unistd.h>
#include <pthread.h>
#include <cmath>
#include <cstring>

#define LOG_TAG "FateImGui"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// 全局变量
static ANativeWindow* g_Window = nullptr;
static bool g_Initialized = false;
static bool g_Running = true;
static pthread_t g_RenderThread;
static pthread_mutex_t g_Mutex = PTHREAD_MUTEX_INITIALIZER;

// 设置参数
float g_BackgroundAlpha = 0.85f;
float g_ShadowAlpha = 0.5f;
float g_IconColor[3] = {1.0f, 1.0f, 1.0f}; // 白色

// 显示尺寸
int g_ScreenWidth = 0;
int g_ScreenHeight = 0;

// OpenGL资源
GLuint g_ShadowProgram = 0;
GLuint g_RectProgram = 0;
GLuint g_TextProgram = 0;
GLuint g_IconProgram = 0;
GLuint g_FateLogoTexture = 0;
GLuint g_VAO = 0;
GLuint g_VBO = 0;

// 顶点着色器
const char* vertexShaderSource = R"(#version 300 es
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aTexCoord;
uniform vec2 uResolution;
uniform vec2 uPosition;
uniform vec2 uSize;
out vec2 vTexCoord;
out vec2 vPos;
void main() {
    vec2 pos = aPos * uSize + uPosition;
    vec2 clipPos = (pos / uResolution) * 2.0 - 1.0;
    gl_Position = vec4(clipPos.x, -clipPos.y, 0.0, 1.0);
    vTexCoord = aTexCoord;
    vPos = aPos;
}
)";

// 片段着色器 - 圆角矩形
const char* rectFragmentShaderSource = R"(#version 300 es
precision mediump float;
in vec2 vTexCoord;
in vec2 vPos;
uniform vec4 uColor;
uniform float uRounding;
uniform vec2 uSize;
out vec4 FragColor;
float roundedRectSDF(vec2 center, vec2 size, float radius) {
    vec2 q = abs(center) - size + radius;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius;
}
void main() {
    float dist = roundedRectSDF(vPos - 0.5, uSize * 0.5, uRounding);
    float alpha = 1.0 - smoothstep(-1.0, 0.0, dist);
    FragColor = vec4(uColor.rgb, uColor.a * alpha);
}
)";

// 片段着色器 - 阴影
const char* shadowFragmentShaderSource = R"(#version 300 es
precision mediump float;
in vec2 vTexCoord;
in vec2 vPos;
uniform vec4 uColor;
uniform float uRounding;
uniform vec2 uSize;
uniform float uBlur;
out vec4 FragColor;
float roundedRectSDF(vec2 center, vec2 size, float radius) {
    vec2 q = abs(center) - size + radius;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius;
}
void main() {
    float dist = roundedRectSDF(vPos - 0.5, uSize * 0.5, uRounding);
    float alpha = 1.0 - smoothstep(-uBlur, 0.0, dist);
    alpha *= smoothstep(-uBlur * 2.0, -uBlur, dist);
    FragColor = vec4(uColor.rgb, uColor.a * alpha);
}
)";

// 片段着色器 - 图标
const char* iconFragmentShaderSource = R"(#version 300 es
precision mediump float;
in vec2 vTexCoord;
in vec2 vPos;
uniform vec3 uColor;
uniform float uTime;
out vec4 FragColor;
float hexagon(vec2 p, float r) {
    vec3 k = vec3(-0.866025404, 0.5, 0.577350269);
    p = abs(p);
    p -= 2.0 * min(dot(k.xy, p), 0.0) * k.xy;
    p -= vec2(clamp(p.x, -k.z * r, k.z * r), r);
    return length(p) * sign(p.y);
}
float box(vec2 p, vec2 b) {
    vec2 d = abs(p) - b;
    return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}
void main() {
    vec2 uv = vPos - 0.5;
    float d1 = box(uv, vec2(0.35)) - 0.05;
    float d2 = hexagon(uv, 0.2);
    float d3 = box(uv, vec2(0.25));
    float corner = box(abs(uv) - vec2(0.3), vec2(0.08)) - 0.03;
    
    float shape = min(max(d1, -d3), min(d2, corner));
    float alpha = 1.0 - smoothstep(-0.02, 0.02, shape);
    
    FragColor = vec4(uColor, alpha);
}
)";

// 编译着色器
GLuint compileShader(GLenum type, const char* source) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    
    GLint success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetShaderInfoLog(shader, 512, nullptr, infoLog);
        LOGE("Shader compilation failed: %s", infoLog);
        glDeleteShader(shader);
        return 0;
    }
    return shader;
}

// 创建着色器程序
GLuint createProgram(const char* vertexSource, const char* fragmentSource) {
    GLuint vertexShader = compileShader(GL_VERTEX_SHADER, vertexSource);
    GLuint fragmentShader = compileShader(GL_FRAGMENT_SHADER, fragmentSource);
    
    if (!vertexShader || !fragmentShader) return 0;
    
    GLuint program = glCreateProgram();
    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);
    glLinkProgram(program);
    
    GLint success;
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetProgramInfoLog(program, 512, nullptr, infoLog);
        LOGE("Program linking failed: %s", infoLog);
        glDeleteProgram(program);
        program = 0;
    }
    
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
    
    return program;
}

// 初始化OpenGL资源
bool initGL() {
    // 创建着色器程序
    g_RectProgram = createProgram(vertexShaderSource, rectFragmentShaderSource);
    g_ShadowProgram = createProgram(vertexShaderSource, shadowFragmentShaderSource);
    g_IconProgram = createProgram(vertexShaderSource, iconFragmentShaderSource);
    
    if (!g_RectProgram || !g_ShadowProgram || !g_IconProgram) {
        LOGE("Failed to create shader programs");
        return false;
    }
    
    // 创建顶点数据
    float vertices[] = {
        // 位置 (x, y)    // 纹理坐标 (u, v)
        0.0f, 0.0f,       0.0f, 0.0f,
        1.0f, 0.0f,       1.0f, 0.0f,
        0.0f, 1.0f,       0.0f, 1.0f,
        1.0f, 1.0f,       1.0f, 1.0f
    };
    
    glGenVertexArrays(1, &g_VAO);
    glGenBuffers(1, &g_VBO);
    
    glBindVertexArray(g_VAO);
    glBindBuffer(GL_ARRAY_BUFFER, g_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);
    
    glBindVertexArray(0);
    
    // 启用混合
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    return true;
}

// 绘制圆角矩形
void drawRoundedRect(float x, float y, float width, float height, float rounding, 
                     float r, float g, float b, float a, bool isShadow = false, float blur = 0.0f) {
    GLuint program = isShadow ? g_ShadowProgram : g_RectProgram;
    glUseProgram(program);
    
    glUniform2f(glGetUniformLocation(program, "uResolution"), (float)g_ScreenWidth, (float)g_ScreenHeight);
    glUniform2f(glGetUniformLocation(program, "uPosition"), x, y);
    glUniform2f(glGetUniformLocation(program, "uSize"), width, height);
    glUniform4f(glGetUniformLocation(program, "uColor"), r, g, b, a);
    glUniform1f(glGetUniformLocation(program, "uRounding"), rounding);
    
    if (isShadow) {
        glUniform1f(glGetUniformLocation(program, "uBlur"), blur);
    }
    
    glBindVertexArray(g_VAO);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glBindVertexArray(0);
}

// 绘制Fate图标
void drawFateIcon(float x, float y, float size, float r, float g, float b) {
    glUseProgram(g_IconProgram);
    
    glUniform2f(glGetUniformLocation(g_IconProgram, "uResolution"), (float)g_ScreenWidth, (float)g_ScreenHeight);
    glUniform2f(glGetUniformLocation(g_IconProgram, "uPosition"), x, y);
    glUniform2f(glGetUniformLocation(g_IconProgram, "uSize"), size, size);
    glUniform3f(glGetUniformLocation(g_IconProgram, "uColor"), r, g, b);
    glUniform1f(glGetUniformLocation(g_IconProgram, "uTime"), 0.0f);
    
    glBindVertexArray(g_VAO);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glBindVertexArray(0);
}

// 绘制圆形
void drawCircle(float cx, float cy, float radius, float r, float g, float b, float a) {
    const int segments = 32;
    float vertices[(segments + 2) * 2];
    
    vertices[0] = cx;
    vertices[1] = cy;
    
    for (int i = 0; i <= segments; i++) {
        float angle = 2.0f * 3.14159f * i / segments;
        vertices[(i + 1) * 2] = cx + radius * cosf(angle);
        vertices[(i + 1) * 2 + 1] = cy + radius * sinf(angle);
    }
    
    GLuint vbo;
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    
    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(0);
    
    glUseProgram(g_RectProgram);
    glUniform4f(glGetUniformLocation(g_RectProgram, "uColor"), r, g, b, a);
    
    glDrawArrays(GL_TRIANGLE_FAN, 0, segments + 2);
    
    glDeleteBuffers(1, &vbo);
    glDeleteVertexArrays(1, &vao);
}

// 绘制文本（简化版 - 使用几何图形）
void drawText(const char* text, float x, float y, float size, float r, float g, float b, float a) {
    // 简化的文本渲染 - 每个字符用矩形表示
    float charWidth = size * 0.6f;
    float spacing = charWidth * 0.2f;
    
    for (int i = 0; text[i]; i++) {
        float cx = x + i * (charWidth + spacing);
        // 绘制简单的字符矩形
        drawRoundedRect(cx, y - size * 0.5f, charWidth * 0.8f, size, 2.0f, r, g, b, a);
    }
}

// 绘制主HUD
void drawHUD() {
    pthread_mutex_lock(&g_Mutex);
    float bgAlpha = g_BackgroundAlpha;
    float shadowAlpha = g_ShadowAlpha;
    float iconR = g_IconColor[0];
    float iconG = g_IconColor[1];
    float iconB = g_IconColor[2];
    pthread_mutex_unlock(&g_Mutex);
    
    // HUD尺寸和位置
    float hudWidth = 520.0f;
    float hudHeight = 50.0f;
    float hudX = (g_ScreenWidth - hudWidth) * 0.5f;
    float hudY = 50.0f;
    float rounding = 25.0f;
    float shadowSize = 20.0f;
    
    // 绘制阴影（多层）
    for (int i = 5; i >= 0; i--) {
        float offset = i * 2.0f;
        float alpha = shadowAlpha * (1.0f - (float)i / 6.0f) * 0.3f;
        drawRoundedRect(hudX - offset, hudY - offset, 
                       hudWidth + offset * 2, hudHeight + offset * 2,
                       rounding + offset, 0.0f, 0.0f, 0.0f, alpha, true, 10.0f);
    }
    
    // 绘制背景
    drawRoundedRect(hudX, hudY, hudWidth, hudHeight, rounding, 
                   0.12f, 0.12f, 0.14f, bgAlpha);
    
    // 绘制边框
    drawRoundedRect(hudX + 1, hudY + 1, hudWidth - 2, hudHeight - 2, rounding - 1,
                   0.25f, 0.25f, 0.28f, bgAlpha * 0.5f);
    
    float contentX = hudX + 15.0f;
    float centerY = hudY + hudHeight * 0.5f;
    
    // 绘制Fate图标
    drawFateIcon(contentX, centerY - 14.0f, 28.0f, iconR, iconG, iconB);
    contentX += 40.0f;
    
    // 绘制 "Fate" 文字（使用几何图形模拟）
    // F
    drawRoundedRect(contentX, centerY - 10.0f, 4.0f, 20.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    drawRoundedRect(contentX, centerY - 10.0f, 12.0f, 4.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    drawRoundedRect(contentX, centerY - 2.0f, 8.0f, 3.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    contentX += 18.0f;
    
    // a
    drawRoundedRect(contentX + 4.0f, centerY - 5.0f, 10.0f, 10.0f, 4.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    drawRoundedRect(contentX + 8.0f, centerY - 10.0f, 3.0f, 15.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    contentX += 18.0f;
    
    // t
    drawRoundedRect(contentX + 4.0f, centerY - 12.0f, 3.0f, 22.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    drawRoundedRect(contentX, centerY - 5.0f, 12.0f, 3.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    contentX += 16.0f;
    
    // e
    drawRoundedRect(contentX, centerY - 8.0f, 12.0f, 16.0f, 6.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    drawRoundedRect(contentX + 2.0f, centerY - 2.0f, 8.0f, 3.0f, 1.0f, 0.12f, 0.12f, 0.14f, bgAlpha);
    contentX += 20.0f;
    
    // 分隔点
    contentX += 5.0f;
    drawCircle(contentX + 2.0f, centerY, 2.5f, 0.6f, 0.6f, 0.6f, 1.0f);
    contentX += 15.0f;
    
    // 用户图标（头像）
    drawCircle(contentX + 10.0f, centerY, 10.0f, 0.4f, 0.6f, 0.8f, 1.0f);
    drawCircle(contentX + 10.0f, centerY - 3.0f, 4.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    drawRoundedRect(contentX + 4.0f, centerY + 2.0f, 12.0f, 6.0f, 3.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    contentX += 30.0f;
    
    // "YaoMao" 文字
    const char* username = "YaoMao";
    for (int i = 0; username[i]; i++) {
        drawRoundedRect(contentX + i * 12.0f, centerY - 8.0f, 9.0f, 16.0f, 2.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    }
    contentX += 85.0f;
    
    // 分隔点
    drawCircle(contentX + 2.0f, centerY, 2.5f, 0.6f, 0.6f, 0.6f, 1.0f);
    contentX += 15.0f;
    
    // 延迟图标（信号条）
    float pingColorR = 0.4f, pingColorG = 1.0f, pingColorB = 0.4f;
    drawRoundedRect(contentX, centerY - 6.0f, 4.0f, 12.0f, 1.0f, pingColorR, pingColorG, pingColorB, 1.0f);
    drawRoundedRect(contentX + 6.0f, centerY - 8.0f, 4.0f, 16.0f, 1.0f, pingColorR, pingColorG, pingColorB, 1.0f);
    drawRoundedRect(contentX + 12.0f, centerY - 4.0f, 4.0f, 8.0f, 1.0f, pingColorR, pingColorG, pingColorB, 1.0f);
    contentX += 22.0f;
    
    // "67ms" 文字
    drawRoundedRect(contentX, centerY - 8.0f, 10.0f, 16.0f, 2.0f, pingColorR, pingColorG, pingColorB, 1.0f);
    contentX += 15.0f;
    const char* pingText = "ms to mc.hypixel.net";
    for (int i = 0; pingText[i]; i++) {
        drawRoundedRect(contentX + i * 8.0f, centerY - 6.0f, 6.0f, 12.0f, 1.0f, pingColorR, pingColorG, pingColorB, 1.0f);
    }
    contentX += 170.0f;
    
    // 分隔点
    drawCircle(contentX + 2.0f, centerY, 2.5f, 0.6f, 0.6f, 0.6f, 1.0f);
    contentX += 15.0f;
    
    // FPS图标（刷新箭头）
    drawCircle(contentX + 8.0f, centerY, 6.0f, 0.0f, 0.0f, 0.0f, 0.0f); // 圆环
    drawRoundedRect(contentX + 12.0f, centerY - 4.0f, 6.0f, 4.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    contentX += 22.0f;
    
    // "144 fps" 文字
    const char* fpsText = "144 fps";
    for (int i = 0; fpsText[i]; i++) {
        drawRoundedRect(contentX + i * 10.0f, centerY - 7.0f, 7.0f, 14.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    }
}

// 绘制设置面板
void drawSettingsPanel() {
    pthread_mutex_lock(&g_Mutex);
    float bgAlpha = g_BackgroundAlpha;
    float shadowAlpha = g_ShadowAlpha;
    float iconR = g_IconColor[0];
    float iconG = g_IconColor[1];
    float iconB = g_IconColor[2];
    pthread_mutex_unlock(&g_Mutex);
    
    float panelWidth = 400.0f;
    float panelHeight = 280.0f;
    float panelX = (g_ScreenWidth - panelWidth) * 0.5f;
    float panelY = 120.0f;
    float rounding = 16.0f;
    
    // 绘制阴影
    for (int i = 4; i >= 0; i--) {
        float offset = i * 2.0f;
        float alpha = 0.3f * (1.0f - (float)i / 5.0f);
        drawRoundedRect(panelX - offset, panelY - offset,
                       panelWidth + offset * 2, panelHeight + offset * 2,
                       rounding + offset, 0.0f, 0.0f, 0.0f, alpha, true, 8.0f);
    }
    
    // 绘制背景
    drawRoundedRect(panelX, panelY, panelWidth, panelHeight, rounding,
                   0.15f, 0.15f, 0.18f, 0.95f);
    
    // 标题
    float titleX = panelX + 20.0f;
    float titleY = panelY + 25.0f;
    
    // "Settings" 标题
    const char* title = "Fate Settings";
    for (int i = 0; title[i]; i++) {
        drawRoundedRect(titleX + i * 12.0f, titleY - 8.0f, 9.0f, 16.0f, 2.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    // 分隔线
    drawRoundedRect(panelX + 20.0f, titleY + 20.0f, panelWidth - 40.0f, 2.0f, 1.0f, 0.3f, 0.3f, 0.35f, 0.5f);
    
    // Background Opacity 标签
    float sliderY = titleY + 50.0f;
    const char* bgLabel = "Background Opacity";
    for (int i = 0; bgLabel[i]; i++) {
        drawRoundedRect(panelX + 20.0f + i * 7.0f, sliderY - 6.0f, 5.0f, 12.0f, 1.0f, 0.8f, 0.8f, 0.8f, 1.0f);
    }
    
    // 背景透明度滑块背景
    float sliderX = panelX + 20.0f;
    float sliderWidth = panelWidth - 40.0f;
    drawRoundedRect(sliderX, sliderY + 15.0f, sliderWidth, 12.0f, 6.0f, 0.3f, 0.3f, 0.35f, 1.0f);
    // 滑块填充
    drawRoundedRect(sliderX, sliderY + 15.0f, sliderWidth * bgAlpha, 12.0f, 6.0f, 0.3f, 0.7f, 1.0f, 1.0f);
    // 滑块按钮
    drawRoundedRect(sliderX + sliderWidth * bgAlpha - 8.0f, sliderY + 12.0f, 16.0f, 18.0f, 8.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    
    // Shadow Opacity 标签
    sliderY += 55.0f;
    const char* shadowLabel = "Shadow Opacity";
    for (int i = 0; shadowLabel[i]; i++) {
        drawRoundedRect(panelX + 20.0f + i * 7.0f, sliderY - 6.0f, 5.0f, 12.0f, 1.0f, 0.8f, 0.8f, 0.8f, 1.0f);
    }
    
    // 阴影透明度滑块
    drawRoundedRect(sliderX, sliderY + 15.0f, sliderWidth, 12.0f, 6.0f, 0.3f, 0.3f, 0.35f, 1.0f);
    drawRoundedRect(sliderX, sliderY + 15.0f, sliderWidth * shadowAlpha, 12.0f, 6.0f, 0.3f, 0.7f, 1.0f, 1.0f);
    drawRoundedRect(sliderX + sliderWidth * shadowAlpha - 8.0f, sliderY + 12.0f, 16.0f, 18.0f, 8.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    
    // Icon Color 标签
    sliderY += 55.0f;
    const char* colorLabel = "Icon Color";
    for (int i = 0; colorLabel[i]; i++) {
        drawRoundedRect(panelX + 20.0f + i * 7.0f, sliderY - 6.0f, 5.0f, 12.0f, 1.0f, 0.8f, 0.8f, 0.8f, 1.0f);
    }
    
    // 颜色选择器（简化的调色盘）
    float colorPickerX = panelX + 20.0f;
    float colorPickerY = sliderY + 20.0f;
    float colorSize = 30.0f;
    float colorSpacing = 10.0f;
    
    // 预设颜色
    const float presets[][3] = {
        {1.0f, 1.0f, 1.0f},  // White
        {1.0f, 0.0f, 0.0f},  // Red
        {0.0f, 1.0f, 0.0f},  // Green
        {0.0f, 0.5f, 1.0f},  // Blue
        {1.0f, 0.8f, 0.0f},  // Gold
        {0.8f, 0.0f, 1.0f},  // Purple
        {0.0f, 1.0f, 1.0f},  // Cyan
        {1.0f, 0.5f, 0.0f},  // Orange
    };
    
    for (int i = 0; i < 8; i++) {
        float cx = colorPickerX + (i % 4) * (colorSize + colorSpacing);
        float cy = colorPickerY + (i / 4) * (colorSize + colorSpacing);
        drawRoundedRect(cx, cy, colorSize, colorSize, 4.0f, 
                       presets[i][0], presets[i][1], presets[i][2], 1.0f);
        // 选中边框
        if (fabsf(iconR - presets[i][0]) < 0.01f &&
            fabsf(iconG - presets[i][1]) < 0.01f &&
            fabsf(iconB - presets[i][2]) < 0.01f) {
            drawRoundedRect(cx - 2.0f, cy - 2.0f, colorSize + 4.0f, colorSize + 4.0f, 5.0f,
                           1.0f, 1.0f, 1.0f, 0.8f);
        }
    }
    
    // RGB值显示
    float rgbY = colorPickerY + 90.0f;
    const char* rgbLabel = "RGB Values";
    for (int i = 0; rgbLabel[i]; i++) {
        drawRoundedRect(panelX + 20.0f + i * 7.0f, rgbY - 6.0f, 5.0f, 12.0f, 1.0f, 0.8f, 0.8f, 0.8f, 1.0f);
    }
    
    // RGB滑块
    float rgbSliderY = rgbY + 20.0f;
    // R
    drawRoundedRect(panelX + 20.0f, rgbSliderY, 100.0f, 10.0f, 5.0f, 0.3f, 0.3f, 0.35f, 1.0f);
    drawRoundedRect(panelX + 20.0f, rgbSliderY, 100.0f * iconR, 10.0f, 5.0f, 1.0f, 0.2f, 0.2f, 1.0f);
    // G
    drawRoundedRect(panelX + 140.0f, rgbSliderY, 100.0f, 10.0f, 5.0f, 0.3f, 0.3f, 0.35f, 1.0f);
    drawRoundedRect(panelX + 140.0f, rgbSliderY, 100.0f * iconG, 10.0f, 5.0f, 0.2f, 1.0f, 0.2f, 1.0f);
    // B
    drawRoundedRect(panelX + 260.0f, rgbSliderY, 100.0f, 10.0f, 5.0f, 0.3f, 0.3f, 0.35f, 1.0f);
    drawRoundedRect(panelX + 260.0f, rgbSliderY, 100.0f * iconB, 10.0f, 5.0f, 0.2f, 0.2f, 1.0f, 1.0f);
}

// 渲染线程
void* RenderThread(void* arg) {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    
    // 初始化EGL
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(display, nullptr, nullptr);
    
    EGLint attribs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_NONE
    };
    
    EGLConfig config;
    EGLint numConfigs;
    eglChooseConfig(display, attribs, &config, 1, &numConfigs);
    
    EGLint format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &format);
    
    ANativeWindow_setBuffersGeometry(g_Window, 0, 0, format);
    
    surface = eglCreateWindowSurface(display, config, g_Window, nullptr);
    
    EGLint contextAttribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };
    context = eglCreateContext(display, config, EGL_NO_CONTEXT, contextAttribs);
    
    eglMakeCurrent(display, surface, surface, context);
    
    // 获取窗口尺寸
    eglQuerySurface(display, surface, EGL_WIDTH, &g_ScreenWidth);
    eglQuerySurface(display, surface, EGL_HEIGHT, &g_ScreenHeight);
    
    LOGI("Screen size: %dx%d", g_ScreenWidth, g_ScreenHeight);
    
    // 初始化OpenGL
    if (!initGL()) {
        LOGE("Failed to initialize OpenGL");
        return nullptr;
    }
    
    // 渲染循环
    while (g_Running) {
        glViewport(0, 0, g_ScreenWidth, g_ScreenHeight);
        glClearColor(0.1f, 0.1f, 0.12f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        // 启用混合
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        
        // 绘制HUD
        drawHUD();
        
        // 绘制设置面板
        drawSettingsPanel();
        
        eglSwapBuffers(display, surface);
        
        usleep(16666); // ~60 FPS
    }
    
    // 清理
    glDeleteProgram(g_RectProgram);
    glDeleteProgram(g_ShadowProgram);
    glDeleteProgram(g_IconProgram);
    glDeleteVertexArrays(1, &g_VAO);
    glDeleteBuffers(1, &g_VBO);
    
    eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroyContext(display, context);
    eglDestroySurface(display, surface);
    eglTerminate(display);
    
    return nullptr;
}

// JNI函数
extern "C" {

JNIEXPORT void JNICALL
Java_com_fate_imgui_NativeHelper_nativeSetSurface(JNIEnv* env, jclass clazz, jobject surface) {
    if (g_Window) {
        ANativeWindow_release(g_Window);
    }
    g_Window = ANativeWindow_fromSurface(env, surface);
    
    if (g_Window && !g_Initialized) {
        g_Initialized = true;
        g_Running = true;
        pthread_create(&g_RenderThread, nullptr, RenderThread, nullptr);
    }
}

JNIEXPORT void JNICALL
Java_com_fate_imgui_NativeHelper_nativeOnPause(JNIEnv* env, jclass clazz) {
    g_Running = false;
    if (g_RenderThread) {
        pthread_join(g_RenderThread, nullptr);
        g_RenderThread = 0;
    }
    g_Initialized = false;
}

JNIEXPORT void JNICALL
Java_com_fate_imgui_NativeHelper_nativeOnResume(JNIEnv* env, jclass clazz) {
    g_Running = true;
}

JNIEXPORT void JNICALL
Java_com_fate_imgui_NativeHelper_nativeSetBackgroundAlpha(JNIEnv* env, jclass clazz, jfloat alpha) {
    pthread_mutex_lock(&g_Mutex);
    g_BackgroundAlpha = alpha;
    pthread_mutex_unlock(&g_Mutex);
}

JNIEXPORT void JNICALL
Java_com_fate_imgui_NativeHelper_nativeSetShadowAlpha(JNIEnv* env, jclass clazz, jfloat alpha) {
    pthread_mutex_lock(&g_Mutex);
    g_ShadowAlpha = alpha;
    pthread_mutex_unlock(&g_Mutex);
}

JNIEXPORT void JNICALL
Java_com_fate_imgui_NativeHelper_nativeSetIconColor(JNIEnv* env, jclass clazz, jfloat r, jfloat g, jfloat b) {
    pthread_mutex_lock(&g_Mutex);
    g_IconColor[0] = r;
    g_IconColor[1] = g;
    g_IconColor[2] = b;
    pthread_mutex_unlock(&g_Mutex);
}

JNIEXPORT jfloat JNICALL
Java_com_fate_imgui_NativeHelper_nativeGetBackgroundAlpha(JNIEnv* env, jclass clazz) {
    return g_BackgroundAlpha;
}

JNIEXPORT jfloat JNICALL
Java_com_fate_imgui_NativeHelper_nativeGetShadowAlpha(JNIEnv* env, jclass clazz) {
    return g_ShadowAlpha;
}

JNIEXPORT jfloatArray JNICALL
Java_com_fate_imgui_NativeHelper_nativeGetIconColor(JNIEnv* env, jclass clazz) {
    jfloatArray result = env->NewFloatArray(3);
    jfloat colors[3] = {g_IconColor[0], g_IconColor[1], g_IconColor[2]};
    env->SetFloatArrayRegion(result, 0, 3, colors);
    return result;
}

} // extern "C"
